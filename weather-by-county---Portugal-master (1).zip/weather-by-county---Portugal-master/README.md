# trial
start with "node app.js"
the site will be listening on localhost:3000

# Requirements
Tal como falamos segue o desafio.

Criar uma app web, em node.js ou semelhante com as seguintes funcionalidades:
- lista de cidades (com instant filling) consumido por serviço
- depois de seleccionar uma cidade, consumir novo serviço para obter estado do tempo para o dia actual.
- incluir opção para apresentar popup com estado do tempo para o dia/dias seguintes.

Qualquer dúvida pergunta.
